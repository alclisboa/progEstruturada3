//3. Fa�a um programa que entra com a idade de uma pessoa e se idade maior que 70 anos, aparece a mensagem "Novos 50". Se idade maior que 21 anos, Adulto. Se idade menor que 21 anos, Jovem.

#include <stdio.h>
#include <locale.h>

int main() {
   int idade;

   setlocale(LC_ALL, "Portuguese");

   printf("Digite a sua idade:\n");
   fflush(stdout);
   scanf("%d", &idade);
   fflush(stdout);

   if (idade > 70) {
      printf("Novos 50\n");
      fflush(stdout);
   } else {
      if (idade > 21) {
         printf("Adulto\n");
         fflush(stdout);
      } else {
         printf("Jovem\n");
      }
   }

   return 0;
}
