//1. Programa que calcule a m�dia de 5 notas de um aluno.

#include <stdio.h>
#include <locale.h>

int main() {

   float nota1, nota2, nota3, nota4, nota5;
   float media;

   setlocale(LC_ALL, "Portuguese");

   printf("Digite as 5 notas do aluno:\n");
   fflush(stdout);
   scanf("%f %f %f %f %f", &nota1, &nota2, &nota3, &nota4, &nota5);
   fflush(stdout);

   media = (nota1 + nota2 + nota3 + nota4 + nota5) / 5;

   printf("A media das notas do aluno e: %.2f\n", media);

   return 0;
}

