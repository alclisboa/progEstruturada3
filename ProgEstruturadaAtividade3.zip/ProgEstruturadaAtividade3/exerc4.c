//4. Elabore um programa para verifica��o de situa��o eleitoral, onde ser� informada somente a idade do eleitor, considere as situa��es abaixo:
//
//Menor que 0 n�o nasceu
//0-15 n�o vota
//16-17 opcional
//18-65 obrigat�rio
//exatamente 41- somente ganha pr�mio e n�o vota!!!
//> 65 opcional
//exatamente 88 - somente ganha pr�mio e n�o vota!!!
//
//- N�o utilizar os operadores l�gicos || ou &&
//- Utilizar somente estrutura if/else conforme apresentada abaixo
//- N�o utilizar switch/case
//- N�o utilizar a estrutura "else if"

#include <stdio.h>
#include <locale.h>

int main() {
   int idade;

   setlocale(LC_ALL, "Portuguese");

   printf("Digite a sua idade:\n");
   fflush(stdout);
   scanf("%d", &idade);
   fflush(stdout);

   if (idade < 0) {
      printf("Nao nasceu\n");
      fflush(stdout);
   } else {
      if (idade >= 0 && idade <= 15) {
         printf("Nao vota\n");
         fflush(stdout);
      } else {
         if (idade >= 16 && idade <= 17) {
            printf("Voto opcional\n");
            fflush(stdout);
         } else {
            if (idade >= 18 && idade <= 65) {
               printf("Voto obrigatorio\n");
               fflush(stdout);
            } else {
               if (idade == 41 || idade == 88) {
                  printf("Ganha premio e nao vota\n");
                  fflush(stdout);
               } else {
                  printf("Voto opcional\n");
               }
            }
         }
      }
   }

   return 0;
}

