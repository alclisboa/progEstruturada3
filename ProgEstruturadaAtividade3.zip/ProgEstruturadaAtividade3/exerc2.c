//2. Fa�a um programa que receba a idade de uma pessoa e se idade menor que 30 aparece a mensagem "Voc� � muito jovem". Caso idade maior que 30 anos, o programa n�o far� nada.

#include <stdio.h>
#include <locale.h>

int main() {
   int idade;

   setlocale(LC_ALL, "Portuguese");

   printf("Digite a sua idade:\n");
   fflush(stdout);
   scanf("%d", &idade);
   fflush(stdout);

   if (idade < 30) {
      printf("Voce e muito jovem\n");
   }

   return 0;
}
